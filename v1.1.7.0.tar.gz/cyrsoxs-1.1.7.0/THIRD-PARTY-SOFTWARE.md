# Third Party Software Licenses

[pybind11](https://github.com/pybind/pybind11) is provided under
the terms of the three-clause BSD license reproduced at
[external/pybind11/LICENSE](external/pybind11/LICENSE).
