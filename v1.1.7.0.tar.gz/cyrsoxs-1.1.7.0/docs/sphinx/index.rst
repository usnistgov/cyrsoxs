.. CyRSoXS documentation master file, created by
   sphinx-quickstart on Thu Oct 20 14:28:05 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CyRSoXS's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
