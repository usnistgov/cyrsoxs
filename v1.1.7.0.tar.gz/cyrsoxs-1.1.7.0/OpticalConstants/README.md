# Optical Constants

Optical Constants derived from a polyethylene oligmer measured at the 11.0.1.2 RSoXS beamline of the Advanced Light Source are contained in the PEOlig2018.txt file. The constants are in a format compatible with CyRSoXS, and tabulated from 0-30keV.
